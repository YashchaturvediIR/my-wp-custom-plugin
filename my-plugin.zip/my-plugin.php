<?php
/*
 * Plugin Name: Yash Website Custom Plugin
 * Description: Handle the custom functions for the yashchaturvedi.great-site.net
 */
add_filter('show_admin_bar', '__return_false');